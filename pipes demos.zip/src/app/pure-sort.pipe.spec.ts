import { PureSortPipe } from './pure-sort.pipe';

describe('PureSortPipe', () => {
  it('create an instance', () => {
    const pipe = new PureSortPipe();
    expect(pipe).toBeTruthy();
  });
});
