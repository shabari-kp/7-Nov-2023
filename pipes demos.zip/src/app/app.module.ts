import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TruncatePipe } from './truncate.pipe';
import { FilterPipe } from './filter.pipe';
import { FormsModule } from '@angular/forms';
import { PureSortPipe } from './pure-sort.pipe';
import { ImpureSortPipe } from './impure-sort.pipe';
import { SortingDemoComponent } from './sorting-demo/sorting-demo.component';

@NgModule({
  declarations: [
    AppComponent,
    TruncatePipe,
    FilterPipe,
    PureSortPipe,
    ImpureSortPipe,
    SortingDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
