import { ImpureSortPipe } from './impure-sort.pipe';

describe('ImpureSortPipe', () => {
  it('create an instance', () => {
    const pipe = new ImpureSortPipe();
    expect(pipe).toBeTruthy();
  });
});
