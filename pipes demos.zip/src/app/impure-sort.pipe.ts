import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'impureSort',
  pure:false // impure pipe
})
export class ImpureSortPipe implements PipeTransform {

  transform(array: number[], args?: any): any {
    return array.sort((a: number, b: number) => b - a);
  }

}
